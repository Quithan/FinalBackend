// Import the required modules
const bcrypt = require('bcrypt');
const express = require('express');
const session = require('express-session');
const passport = require('passport');
const LocalStrategy = require('passport-local').Strategy;

// Create an express app
const app = express();

// Set up the session middleware
app.use(session({
  secret: 'some secret key', // change this to a secure and random key
  resave: false,
  saveUninitialized: false,
  cookie: {
    maxAge: 24 * 60 * 60 * 1000 // one day
  }
}));

// Set up the passport middleware
app.use(passport.initialize());
app.use(passport.session());

// Define the local strategy for passport
passport.use(new LocalStrategy(
  function(username, password, done) {
    // Find the user from the database by username
    User.findOne({ username: username }, function(err, user) {
      if (err) { return done(err); } // handle database error
      if (!user) { return done(null, false); } // user not found
      // Compare the password with bcrypt
      bcrypt.compare(password, user.password, function(err, result) {
        if (err) { return done(err); } // handle bcrypt error
        if (!result) { return done(null, false); } // password mismatch
        return done(null, user); // authentication success
      });
    });
  }
));

// Define the serialization and deserialization functions for passport
passport.serializeUser(function(user, done) {
  // Store the user's ID and role in the session
  done(null, { id: user.id, role: user.role });
});

passport.deserializeUser(function(obj, done) {
  // Find the user from the database by ID
  User.findById(obj.id, function(err, user) {
    if (err) { return done(err); } // handle database error
    if (!user) { return done(null, false); } // user not found
    done(null, user); // deserialization success
  });
});

// Define a helper function to check if the user is authenticated
function isAuthenticated(req, res, next) {
  if (req.isAuthenticated()) {
    return next(); // user is authenticated, proceed to the next middleware
  }
  res.redirect('/login'); // user is not authenticated, redirect to the login page
}

// Define a helper function to check if the user is authorized
function isAuthorized(role) {
  return function(req, res, next) {
    if (req.user && req.user.role === role) {
      return next(); // user is authorized, proceed to the next middleware
    }
    res.status(403).send('Forbidden'); // user is not authorized, send a 403 error
  }
}

// Define the routes for the web application
app.get('/', function(req, res) {
  // This is the main page, anyone can access it
  res.send('Welcome to the main page');
});

app.get('/login', function(req, res) {
  // This is the login page, anyone can access it
  res.send('Please enter your username and password');
});

app.post('/login', passport.authenticate('local', {
  successRedirect: '/', // if authentication succeeds, redirect to the main page
  failureRedirect: '/login' // if authentication fails, redirect to the login page
}));

app.get('/logout', function(req, res) {
  // This is the logout route, only authenticated users can access it
  req.logout(); // log out the user
  res.redirect('/'); // redirect to the main page
});

app.get('/admin', isAuthenticated, isAuthorized('admin'), function(req, res) {
  // This is the admin page, only authenticated and authorized users can access it
  res.send('Welcome to the admin page');
});

app.get('/user', isAuthenticated, isAuthorized('user'), function(req, res) {
  // This is the user page, only authenticated and authorized users can access it
  res.send('Welcome to the user page');
});

// Start the server
app.listen(3000, function() {
  console.log('Server is running on port 3000');
});
